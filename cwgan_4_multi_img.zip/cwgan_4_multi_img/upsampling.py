# -*- coding: utf-8 -*-

import os
import numpy as np

from nilearn.input_data import NiftiMasker
from nilearn.image import new_img_like, resample_img
from nilearn.image import threshold_img, index_img
import nibabel
from scipy import stats

from nilearn import plotting
import matplotlib
from matplotlib import pyplot as plt
import cPickle as pickle
import pickle as pkl
import nilearn.masking as masking
from nilearn.image import load_img
base_dir ='/home/nfs/zpy/BrainPedia/pkl/'


def upsample_vectorized(vecdata):
    '''
    this function upsampled vectorized data to a brain image
    INPUT:
    vecdata: masked and vectorized brain data matrix of size (K, D). K is # maps, D is dimensionality
    maskdata: resampled data shape i.e. (dx, dy, dz)
    '''
    # get mask
    #smallmaskFile = open(base_dir + 'outmask_5_p2.pkl', 'rb')
    #smallmasker = pickle.load(smallmaskFile)
    inmask,smallmasker = down_mask(4.0)
    # VOXEL-iZE brain data
    subbraindata = smallmasker.inverse_transform(vecdata)
    #print(sub)
    # Upsample to brain space
    braindata = upsample_voxels(inmask,subbraindata)

    return braindata


# 在前面那个函数中调用了
def upsample_voxels(masker,voxeldata):
    '''
    this function upsamples brain data to a full brain image
    INPUT:
    vecdata: masked and vectorized brain data matrix of size (K, D). K is # maps, D is dimensionality
    maskdata: resampled data shape i.e. (dx, dy, dz)
    '''
    # get mask

    # maskFile = open(base_dir + 'msk_p2.pkl', 'rb')
    # masker = pkl.load(maskFile)

    # RESAMPLE to full brain space
    braindata = resample_img(voxeldata, target_affine=masker.get_affine(),
                             target_shape=masker.shape, interpolation='continuous')

    # 不太懂这里是做什么的，但是看起来没啥影响
    # zero out non-grey matter vozels in upsampled data
    zeromasker = NiftiMasker(mask_img=masker, standardize=False)
    zeromasker.fit()
    temp = zeromasker.transform(braindata)
    braindata = zeromasker.inverse_transform(temp)

    return braindata

def down_mask(scaling=1.0):
    data_path = '/data/zpy/BrainPedia/original/'

    collection = os.listdir(data_path)
    imgs = []
    count = 0
    for i in collection:
        if (str(i)[-2:] == 'gz'):
            count += 1
            imgs.append(load_img(data_path + i))
            if (count % 500 == 0 or count == 6573):  # 每隔500个一存，或者全部读完
                inmask = masking.compute_background_mask(imgs)
                break

    outshape = tuple([int(float(x) / scaling) for x in inmask.shape])
    #print(outshape)
    realscale = float(inmask.shape[0]) / float(outshape[0])
    new_affine = inmask.get_affine().copy()
    new_affine[:3, :3] *= realscale

    #print(realscale)
    # resample mask
    outmask = resample_img(inmask, target_affine=new_affine,
                           target_shape=outshape, interpolation='nearest')
    outmasker = NiftiMasker(mask_img=outmask, standardize=False)
    outmasker.fit()
    return inmask,outmasker

